extern int cntloop;
extern int maxloop; 